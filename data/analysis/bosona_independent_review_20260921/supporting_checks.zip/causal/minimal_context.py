import json,sys,sqlite3,tempfile,bisect
from pathlib import Path
from collections import Counter
sys.path.insert(0,'/home/taygun/Masaüstü/polymarket-bosona/analiz/izleme')
import bosona_rebound_shadow as r
root=Path('/home/taygun/Masaüstü/polymarket-bosona/data/analysis/bosona_inventory_20260921/status_1321')
cutoff=json.loads((root/'runtime.json').read_text())['captured_ms']
events=[e for line in (root/'inventory.jsonl').read_text().splitlines() if (e:=json.loads(line))['recorded_ms']<=cutoff]
raw=json.loads((root/'prices.json').read_text())
counts=Counter(); recovered=[]
with tempfile.TemporaryDirectory() as t:
 db=Path(t)/'prices.db'
 with sqlite3.connect(db) as c:
  c.execute('CREATE TABLE prices(received_ms,observed_ms,source,price)')
  c.executemany('INSERT INTO prices VALUES(?,?,?,?)',raw)
 for e in events:
  if e['kind']!='decision':continue
  when,S=e['feature_cutoff_ms'],e['S']
  candle=next(v['bars'] for v in reversed(events) if v['kind']=='bars' and v['recorded_ms']<=when)
  market=next(v['market'] for v in events if v['kind']=='market' and v['S']==S)
  try:old_side=r.decide(db,S,when,e['books'],candle,market)[1]; old_ok=True
  except r.ERRORS as ex:old_ok=False;old_error=str(ex)
  counts['current_valid']+=old_ok
  try:
   assert candle['received_ms']<=when
   f=r.deep.candle_features(([v[6] for v in candle['rows']],candle['rows']),when)
   streams,starts=r.base.live_inputs(db,S,when)
   known={obs:float(price) for received,(obs,price) in zip(*streams['spot']) if obs<=received<=when}
   ts=sorted(known)
   def at(target):
    i=bisect.bisect_right(ts,target)-1
    if i<0 or not 0<=target-ts[i]<=3000:raise ValueError('stale required spot')
    return known[ts[i]]
   f['momentum']=at(when)-at(when-10000)
   side=r.deep.rebound_side(f,[(b['bid'],b['ask']) for b in e['books']])
   minimal_ok=True
  except (AssertionError,*r.ERRORS):minimal_ok=False
  counts['minimal_valid']+=minimal_ok
  if old_ok:assert minimal_ok and side==old_side
  if minimal_ok and not old_ok:
   detail=None
   for name,(times,values) in streams.items():
    mapping={obs:price for received,(obs,price) in zip(times,values) if obs<=received<=when}
    streams[name]=sorted(mapping),[(obs,mapping[obs]) for obs in sorted(mapping)]
   try:r.base.signals(streams,starts,S,when)
   except r.ERRORS as ex:detail='signals: '+str(ex)
   recovered.append({'S':S,'age':e['age'],'current_error':old_error,'minimal_side':side,'detail':detail})
print(json.dumps({'counts':dict(counts),'restored':recovered}))
