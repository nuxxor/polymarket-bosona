from pathlib import Path
import sys,json,hashlib
from unittest.mock import patch
sys.path.insert(0,'/home/taygun/Masaüstü/polymarket-bosona/analiz/izleme')
import bosona_rebound_shadow as r
import bosona_inventory_shadow as inv
root=Path('/home/taygun/Masaüstü/polymarket-bosona')
# An HTTP response generated during a still-open candle can arrive after its declared close.
minute=1800000000000
rows=[[minute+i*60000,'100','101','99','100','1',minute+(i+1)*60000-1,'100',1,'1'] for i in range(-29,1)]
requested=minute+59500
received=minute+62200
with patch.object(r,'now_ms',side_effect=[requested,received]),patch.object(r.base,'get',return_value=rows):
    candle=r.bars()
assert candle['rows'][-1][6] == minute+59999
assert requested < candle['rows'][-1][6]
assert not r.bars_due(candle,received)

# Scan archived candle responses for demonstrable request/retained-close overlap.
seen={}; crossing=[]
for directory in ['btc5m_feed_fix_20260921','btc5m_status_20260921_1420','btc5m_participation_20260921','bosona_inventory_20260921']:
 for path in (root/'data/analysis'/directory).rglob('*.jsonl'):
  for line in path.read_text().splitlines():
   e=json.loads(line)
   if e.get('kind')!='bars': continue
   b=e['bars']; key=(b['request_ms'],b['received_ms'])
   if key in seen: continue
   seen[key]=1
   for row in b['rows']:
    if b['request_ms'] < row[6]+2000 <= b['received_ms']:
     crossing.append({'file':str(path.relative_to(root)),'request_ms':b['request_ms'],'received_ms':b['received_ms'],'close_ms':row[6],'definitely_preclose_request':b['request_ms']<row[6]})

# Independently replay every archived participation paper fill through current immutable source.
pp=root/'data/analysis/btc5m_participation_20260921'
events=[json.loads(s) for s in (pp/'shadow_forward.jsonl').read_text().splitlines()]
manifest=json.loads((pp/'watch_manifest.json').read_text())
assert manifest['source_sha256']==inv.hashes()
decisions={(e['S'],e['age']):e for e in events if e['kind']=='decision'}
markets={e['S']:e['market'] for e in events if e['kind']=='market'}
positions={}; count=0
for e in events:
 if e['kind']!='execution':continue
 d=decisions[e['S'],e['age']]
 assert e['request_ms']>=d['decision_ms']+(250 if e['speed']=='250' else 0)
 for lane,f in e['fills'].items():
  hist=positions.setdefault((e['S'],lane),[])
  assert inv.execute(d['intents'][lane],hist,e['books'],markets[e['S']],f['age'])==f
  for k in ('observed_ms','received_ms'):
   assert 0<=e['execution_ms']-e['books'][f['side']][k]<=3000
  hist.append(f); count+=1
  p=inv.position(hist)
  assert p['cash']<=15+1e-8 and p['floor']>=-5-1e-8 and abs(p['qty'][0]-p['qty'][1])<=10+1e-8
print(json.dumps({'candle_boundary_defect_reproduced':True,'archived_unique_candle_responses':len(seen),'archived_boundary_crossings':crossing,'participation_source_hash_verified':True,'participation_execution_records_replayed':count,'participation_last_recorded_ms':max(e['recorded_ms'] for e in events)}))
