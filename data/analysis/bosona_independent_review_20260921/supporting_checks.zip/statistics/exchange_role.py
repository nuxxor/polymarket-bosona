import json,gzip,collections
from pathlib import Path
try: import orjson
except ImportError: orjson=json
R=Path('/home/taygun/Masaüstü/polymarket-bosona');D=R/'data/analysis/bosona_derin_20260921';f=json.loads((D/'features.json').read_text()); wanted={r['tx'] for r in f}; txs={}
for path in sorted((D/'tape_snapshots').glob('*.gz')):
 with gzip.open(path,'rb') as fp:d=orjson.loads(fp.read())
 for S,rcv,obs,p in d['trades']:
  tx=p.get('transaction_hash')
  if tx in wanted and tx not in txs:txs[tx]=dict(rcv=rcv,obs=obs,**p)
txs.update(json.loads((D/'new_trade_times.json').read_text()))
mm={}; out=[]
for r in f:
 p=txs.get(r['tx'])
 if not p:continue
 S=r['S']
 if S not in mm:
  for root in [R/'data/analysis/bosona_gec_20260921',D]:
   path=root/f'markets/btc-updown-5m-{S}.json'
   if path.exists():mm[S]=json.loads(json.loads(path.read_text())['clobTokenIds']);break
 side=mm[S].index(p['asset_id']); premium=r['cost']-r['price'];out.append(dict(S=S,tx=r['tx'],kind=r['kind'],age=r['age'],q=r['q'],pnl=r['pnl'],actor_side=r['side'],event_side=side,event_action=p['side'],event_price=float(p['price']),event_qty=float(p['size']),actor_price=r['price'],premium=premium,same_asset=side==r['side'],event_price_delta=float(p['price'])-(r['price'] if side==r['side'] else 1-r['price'])))
summary={}
for name,rr in [('all',out),('add',[r for r in out if r['kind']=='add']),('late20add',[r for r in out if r['kind']=='add' and r['age']>=280])]:
 by=collections.defaultdict(list)
 for r in rr:by[str((r['same_asset'],r['event_action'],r['premium']>1e-6))].append(r)
 summary[name]={k:dict(n=len(v),windows=len({r['S'] for r in v}),shares=sum(r['q'] for r in v),pnl=sum(r['pnl'] for r in v),matching_price=sum(abs(r['event_price_delta'])<1e-6 for r in v),matching_qty=sum(abs(r['q']-r['event_qty'])<1e-5 for r in v)) for k,v in by.items()}
Path('/tmp/bosona-independent-statistics/exchange_role.json').write_text(json.dumps(dict(summary=summary,rows=out),indent=2));print(json.dumps(summary,indent=2))
