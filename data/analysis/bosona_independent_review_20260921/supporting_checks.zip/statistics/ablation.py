import sys,json,gzip,statistics,collections
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/home/taygun/Masaüstü/polymarket-bosona/analiz/izleme')
import bosona_gec_arastirma as base
try: import orjson
except ImportError: orjson=json
D=base.ROOT/'data/analysis/bosona_derin_20260921'
rows=[r for r in json.loads((D/'policy_rows.json').read_text()) if r['age']==280 and r['rule']=='rebound']; wanted={r['S'] for r in rows}; snaps={}
for path in sorted((D/'tape_snapshots').glob('*.gz')):
 with gzip.open(path,'rb') as f: d=orjson.loads(f.read())
 for S,t,pair in d['snapshots']:
  if S in wanted and t-S*1000 in [280000,280250]: snaps[S,t]=pair
mm={}
for S in wanted:
 for root in [D,base.OUT]:
  path=root/f'markets/btc-updown-5m-{S}.json'
  if path.exists():mm[S]=json.loads(path.read_text());break
for root in [base.OUT/'books',base.OUT/'execution_books',D/'new_books']:
 for S in wanted:
  path=root/f'{S}.json'
  if not path.exists():continue
  data=orjson.loads(path.read_bytes())
  for offset in [280000,280250]:
   t=S*1000+offset; pair=data.get(str(t))
   if not pair:continue
   out=[]
   for b in pair:
    try: cost,fee=base.ask_cost(b,mm[S])
    except ValueError:cost=fee=None
    out.append([b['bid'],b['ask'],None,None,None,None,cost,fee,b['received_ms'],b['observed_ms']])
   snaps[S,t]=out
result=[]
for r in rows:
 S=r['S']; pair=snaps[S,(S+280)*1000]; ex=snaps[S,(S+280)*1000+250]; mids=[(b[0]+b[1])/2 for b in pair]; side=0 if mids[0]<mids[1] else 1
 selected=pair[side][1]<.5; c=(ex[side][6]+ex[side][7]); winner=base.outcome(mm[S]); pnl=5*(side==winner)-c
 if r['selected']:
  assert r['side']==side and selected and abs(pnl-r['pnl'])<1e-9
 result.append(dict(S=S,cheap_eligible=selected,rebound=r['selected'],side=side,cost=c,pnl=pnl,win=side==winner))
def summary(rr):
 days=collections.defaultdict(float)
 for r in rr:days[datetime.fromtimestamp(r['S'],timezone.utc).strftime('%m-%d')]+=r['pnl']
 p=sum(r['pnl'] for r in rr);return dict(n=len(rr),pnl=p,cost=sum(r['cost'] for r in rr),wins=sum(r['win'] for r in rr),excluding_top3=p-sum(sorted([r['pnl'] for r in rr],reverse=True)[:3]),days=dict(days))
summary_out={name:summary(rr) for name,rr in [('cheap_only',[r for r in result if r['cheap_eligible']]),('rebound',[r for r in result if r['rebound']]),('cheap_excluded_by_rebound',[r for r in result if r['cheap_eligible'] and not r['rebound']]) ]}
Path('/tmp/bosona-independent-statistics/ablation.json').write_text(json.dumps(dict(summary=summary_out,rows=result),indent=2));print(json.dumps(summary_out,indent=2));print('all 23 original costs/pnl reconstructed exactly from cached books')
