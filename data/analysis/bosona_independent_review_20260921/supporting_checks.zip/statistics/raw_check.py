import sys,json,gzip,bisect,hashlib
from pathlib import Path
from datetime import datetime,timezone
try: import orjson
except ImportError: orjson=json
R=Path('/home/taygun/Masaüstü/polymarket-bosona'); D=R/'data/analysis/bosona_derin_20260921'; T=Path('/home/taygun/Masaüstü/polymarket/data/tape')
features=json.loads((D/'features.json').read_text()); output=[]
for S in [1789676700,1789402200]:
 rows=[r for r in features if r['S']==S]
 targets=sorted({r['now'] for r in rows})
 m=json.loads((R/f'data/analysis/bosona_gec_20260921/markets/btc-updown-5m-{S}.json').read_text()); tokens=json.loads(m['clobTokenIds'])
 filename='tape_'+datetime.fromtimestamp(S,timezone.utc).strftime('%Y%m%d_%H')+'.jsonl.gz'
 raw=T/filename; latest={}; snapshots={}; cl={0:[],60:[]}; cursor=0
 with gzip.open(raw,'rb') as f:
  for line in f:
   d=orjson.loads(line); rcv=d.get('rcv')
   if rcv is None: continue
   while cursor<len(targets) and targets[cursor]<rcv:
    snapshots[targets[cursor]]=dict(latest); cursor+=1
   if cursor==len(targets): break
   p=d.get('p') or {}; kind=d.get('k'); obs=int(p.get('timestamp',d.get('src') or rcv))
   if kind=='cl' and p.get('w') in cl and d.get('src') and d['src']<=rcv: cl[p['w']].append((rcv,d['src'],float(p['px'])))
   if kind=='pm:book' and p.get('asset_id') in tokens:
    token=p['asset_id']; bids=[float(x['price']) for x in p.get('bids',[]) if float(x['size'])>0]; asks=[float(x['price']) for x in p.get('asks',[]) if float(x['size'])>0]
    if bids and asks and obs>=latest.get(token,(0,0))[1]: latest[token]=(rcv,obs,max(bids),min(asks))
   if kind=='pm:price_change':
    for c in p.get('price_changes',[]):
     token=c.get('asset_id')
     if token in tokens and c.get('best_bid') is not None and c.get('best_ask') is not None and obs>=latest.get(token,(0,0))[1]: latest[token]=(rcv,obs,float(c['best_bid']),float(c['best_ask']))
 assert cursor==len(targets)
 for t in targets:
  rr=[r for r in rows if r['now']==t]; entry=dict(S=S,public_ages=sorted({r['age'] for r in rr}),context_age=(t-S*1000)/1000,raw_book={},raw_price={})
  for side in {r['side'] for r in rr}:
   record=next(r for r in rr if r['side']==side); q=snapshots[t][tokens[side]]
   assert abs(q[2]-record['bid'])<1e-8 and abs(q[3]-record['ask'])<1e-8,(S,t,q,record['bid'],record['ask'])
   entry['raw_book'][str(side)]=dict(received_age=(q[0]-S*1000)/1000,event_age=(q[1]-S*1000)/1000,bid=q[2],ask=q[3])
  for w,key in [(0,'spot'),(60,'twap')]:
   seq=sorted(cl[w]); times=[x[0] for x in seq]; i=bisect.bisect_right(times,t)-1
   if i>=0:
    q=seq[i]; entry['raw_price'][key]=dict(received_age=(q[0]-S*1000)/1000,event_age=(q[1]-S*1000)/1000,price=q[2],stored=rr[0].get(key),matches=abs(q[2]-rr[0].get(key,0))<1e-8)
  output.append(entry)
Path('/tmp/bosona-independent-statistics/raw_check.json').write_text(json.dumps(output,indent=2))
print(json.dumps(output,indent=2)); print('verified',len(output),'contexts from 2 raw hourly tapes')
