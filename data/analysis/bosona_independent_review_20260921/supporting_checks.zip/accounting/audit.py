#!/usr/bin/env python3
"""Read-only BTC5m accounting audit; stdlib, archived public inputs only."""
from collections import Counter, defaultdict, deque
from datetime import datetime, timezone
from decimal import Decimal as D
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else '/home/taygun/Masaüstü/polymarket-bosona')
BASE = ROOT / 'data/analysis/bosona_gec_20260921'
OUT = Path(__file__).resolve().parent
START, END = 1789257600, 1789943400
read = lambda p: json.loads(p.read_text())
stamp = lambda t: datetime.fromtimestamp(t, timezone.utc).isoformat()
key = lambda r: tuple(str(r.get(k, '')) for k in ('transactionHash', 'timestamp', 'type', 'asset', 'outcomeIndex', 'side', 'size', 'price', 'usdcSize'))
chunks = [read(p) for p in sorted((BASE / 'activity').glob('*.json'))]
assert all(c['complete'] and c['pages'] <= 11 and all(c['start'] <= r['timestamp'] <= c['end'] for r in c['rows']) for c in chunks)
assert all(a['end'] + 1 == b['start'] for a, b in zip(chunks, chunks[1:]))
raw_all = [r for c in chunks for r in c['rows']]
raw = [r for r in raw_all if r.get('slug', '').startswith('btc-updown-5m-') and START <= int(r['slug'].rsplit('-', 1)[1]) < END]
stored = read(BASE / 'activity.json')
windows = read(BASE / 'windows.json')
winners = {w['slug']: w['winner'] for w in windows}
for slug, winner in winners.items():
    m = read(BASE / 'markets' / (slug + '.json'))
    assert m['closed'] and json.loads(m['outcomes']) == ['Up', 'Down']
    assert list(map(D, json.loads(m['outcomePrices'])))[winner] == 1
    assert 'btc-usd-twap-60s-streams' in m['description']

def audit(rows):
    grouped = defaultdict(list)
    for r in rows:
        grouped[r['slug']].append(r)
    result = dict(markets=len(grouped), trades=0, cash=D(0), quantity=D(0), payout=D(0), pair=D(0), residual=D(0), prewindow=0)
    result['types'] = dict(Counter(r['type'] for r in rows))
    per_market, fills, deficits, excess = [], [], [], []
    for slug, events in grouped.items():
        trades = sorted((r for r in events if r['type'] == 'TRADE'), key=lambda r: (r['timestamp'], r['transactionHash'], r['outcomeIndex']))
        assert all(r['side'] == 'BUY' for r in trades)
        s, winner = int(slug.rsplit('-', 1)[1]), winners[slug]
        cash = sum((D(str(r['usdcSize'])) for r in trades), D(0))
        qty = [sum((D(str(r['size'])) for r in trades if r['outcomeIndex'] == side), D(0)) for side in (0, 1)]
        merge = sum((D(str(r['usdcSize'])) for r in events if r['type'] == 'MERGE'), D(0))
        redeem = sum((D(str(r['usdcSize'])) for r in events if r['type'] == 'REDEEM'), D(0))
        gap = qty[winner] - merge - redeem
        if gap > D('.00001'): deficits.append(dict(slug=slug, gap=gap))
        if gap < D('-.00001') or merge > min(qty) + D('.00001'):
            excess.append(dict(slug=slug, payout_excess=-gap, merge_excess=merge-min(qty)))
        lots, paired_pnl, ever = [deque(), deque()], D(0), False
        for r in trades:
            side, q = r['outcomeIndex'], D(str(r['size']))
            price, pre = D(str(r['usdcSize'])) / q, sum((a[0] for a in lots[0]), D(0)) - sum((a[0] for a in lots[1]), D(0))
            remain, paired, pair_pnl = q, D(0), D(0)
            while remain and lots[1-side]:
                lot = lots[1-side][0]
                take = min(remain, lot[0]); pair_pnl += take*(1-price-lot[1]); paired += take
                remain -= take; lot[0] -= take
                if not lot[0]: lots[1-side].popleft()
            label = None
            if remain:
                label = 'first' if not ever else ('add' if pre and side == (0 if pre > 0 else 1) else 'reopen')
                lots[side].append([remain, price]); ever = True
            paired_pnl += pair_pnl
            fills.append(dict(slug=slug, age=r['timestamp']-s, kind=label, qty=q, completion=paired, pair_pnl=pair_pnl, pnl=q*(side == winner)-D(str(r['usdcSize']))))
        residual = sum((q*((side == winner)-price) for side in (0,1) for q, price in lots[side]), D(0))
        assert abs(paired_pnl + residual - (qty[winner]-cash)) < D('1e-15')
        per_market.append(dict(slug=slug, pnl=qty[winner]-cash))
        result['trades'] += len(trades); result['cash'] += cash; result['quantity'] += sum(qty); result['payout'] += qty[winner]
        result['pair'] += paired_pnl; result['residual'] += residual
        result['prewindow'] += sum(r['timestamp'] < s for r in trades)
    result['pnl'] = result['payout'] - result['cash']
    result['top3'] = sorted(per_market, key=lambda r: r['pnl'], reverse=True)[:3]
    result['pnl_excluding_top3'] = result['pnl']-sum(r['pnl'] for r in result['top3'])
    result['cash_receipt_deficits'] = deficits; result['cash_receipt_excess'] = excess
    comps = [r for r in fills if r['completion']]
    result['completion_records'] = len(comps)
    result['completion_negative_pair_records'] = sum(r['pair_pnl'] < 0 for r in comps)
    result['completion_above_98c_records'] = sum(r['pair_pnl']/r['completion'] < D('.02') for r in comps)
    for label, selection in [('postclose', lambda r:r['age']>=300), ('late',lambda r:200<r['age']<300), ('late_add',lambda r:200<r['age']<300 and r['kind']=='add'), ('last20_add',lambda r:280<=r['age']<300 and r['kind']=='add')]:
        fs = [r for r in fills if selection(r)]; sums = defaultdict(D)
        for r in fs: sums[r['slug']] += r['pnl']
        result[label] = dict(records=len(fs), markets=len(sums), pnl=sum(sums.values()), pnl_excluding_top3=sum(sums.values())-sum(sorted(sums.values(),reverse=True)[:3]))
    return result

counts = Counter(map(key,raw)); stored_keys = {key(r) for r in stored}
missing = [r for r in raw if key(r) not in stored_keys]
extras = []
for k, r in {key(r):r for r in raw}.items():
    n = counts[k]-1
    if n and r['type']=='TRADE':
        indexes = [(c['start'], [i for i,a in enumerate(c['rows']) if key(a)==k]) for c in chunks if any(key(a)==k for a in c['rows'])]
        extras.append(dict(slug=r['slug'], extra=n, side=r['outcomeIndex'], qty=r['size'], cost=r['usdcSize'], raw_positions=indexes))
report = dict(commit=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip(), source_sha256=hashlib.sha256((ROOT/'analiz/izleme/bosona_gec_arastirma.py').read_bytes()).hexdigest(), analysis_time=stamp(datetime.now(timezone.utc).timestamp()), cohort_start=stamp(START), cohort_end_exclusive=stamp(END), raw_time_start=stamp(chunks[0]['start']), raw_time_end_inclusive=stamp(chunks[-1]['end']), raw_fetch_ms_range=[min(c['fetched_ms'] for c in chunks),max(c['fetched_ms'] for c in chunks)], raw_chunks=len(chunks), raw_rows=len(raw_all), in_scope_raw_rows=len(raw), stored_rows=len(stored), duplicates=extras, omitted_distinct_keys=len(missing), omitted_distinct_key_types=dict(Counter(r['type'] for r in missing)), omitted_distinct_key_cash=sum(D(str(r['usdcSize'])) for r in missing), stored=audit(stored), multiplicity_preserved=audit(raw))
(OUT/'audit.json').write_text(json.dumps(report,default=str,indent=2))
for cohort in ['stored','multiplicity_preserved']:
    r=report[cohort]
    print(cohort,json.dumps({k:v for k,v in r.items() if k not in ['cash_receipt_deficits','top3']},default=str))
print('written',OUT/'audit.json')
